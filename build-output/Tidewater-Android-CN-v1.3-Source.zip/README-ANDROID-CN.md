# 潮水区：安卓中文版

这是 Tidewater 的中文手机适配版，保留 WebGPU 实时海洋、热带岛屿、游泳、潜水、鲸鱼与快艇体验，并针对安卓横屏触控重新设计操作。

## 手机操作

- 左侧摇杆：移动；推到边缘时奔跑或让快艇加速。
- 右侧空白区域：拖动调整视角。
- 跳跃：步行时跳跃；游泳时上浮。
- 下潜：游泳时持续按住下潜。
- 互动：上船、下船或攀爬梯子。
- 视角：开船时切换第一人称与第三人称。
- 照明：开关手电筒。
- 右侧设置栏：调整海浪、天气、太阳时间、镜头效果和画质。

应用固定为横屏并隐藏系统栏。首次进入时点一下“点击进入海岛”，即可启用声音和全屏体验。

## 设备要求

- 支持 WebGPU 的较新安卓设备和 Android System WebView。
- 推荐 8 GB 以上内存；默认开启动态分辨率，负载较高时会自动降低内部渲染分辨率以稳定帧率。
- 应用内容和素材已随 APK 打包，运行场景不依赖网络。

## 从源码构建

需要 Node.js 22+、JDK 21、Android SDK Platform 36 与 Build Tools 36。

```bash
npm ci
npm run android:sync
cd android
./gradlew assembleDebug
```

生成文件位于 `android/app/build/outputs/apk/debug/app-debug.apk`。

## 开源许可

代码采用 MIT License。第三方音频和模型素材许可见 `CREDITS.md`、`public/audio/CREDITS.md` 与各模型目录中的 `CREDITS.md`。
