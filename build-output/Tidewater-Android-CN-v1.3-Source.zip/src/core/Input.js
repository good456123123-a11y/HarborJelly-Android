// Keyboard / mouse input with pointer lock support.
export class Input {

	constructor( dom ) {

		this.dom = dom;
		this.keys = new Set();
		this.virtualKeys = new Set();
		this.pressed = new Set();
		this.look = { x: 0, y: 0 };
		this.wheel = 0;
		this.mouseDown = false;
		this.rightDown = false;
		this.locked = false;
		this.enabled = true;

		window.addEventListener( 'keydown', ( e ) => {

			if ( e.target && ( e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT' || e.target.tagName === 'TEXTAREA' ) ) return;
			if ( ! this.keys.has( e.code ) ) this.pressed.add( e.code );
			this.keys.add( e.code );
			if ( [ 'Space', 'ArrowUp', 'ArrowDown', 'Tab' ].includes( e.code ) ) e.preventDefault();

		} );
		window.addEventListener( 'keyup', ( e ) => this.keys.delete( e.code ) );
		window.addEventListener( 'blur', () => this.resetVirtual() );
		document.addEventListener( 'visibilitychange', () => {

			if ( document.hidden ) this.resetVirtual();

		} );

		dom.addEventListener( 'mousedown', ( e ) => {

			if ( e.button === 0 ) this.mouseDown = true;
			if ( e.button === 2 ) this.rightDown = true;

		} );
		window.addEventListener( 'mouseup', ( e ) => {

			if ( e.button === 0 ) this.mouseDown = false;
			if ( e.button === 2 ) this.rightDown = false;

		} );
		dom.addEventListener( 'contextmenu', ( e ) => e.preventDefault() );
		window.addEventListener( 'mousemove', ( e ) => {

			if ( this.locked || this.mouseDown || this.rightDown ) {

				this.look.x += e.movementX;
				this.look.y += e.movementY;

			}

		} );
		dom.addEventListener( 'wheel', ( e ) => {

			this.wheel += Math.sign( e.deltaY );
			e.preventDefault();

		}, { passive: false } );

		document.addEventListener( 'pointerlockchange', () => {

			this.locked = document.pointerLockElement === dom;

		} );

	}

	requestLock() {

		if ( ! this.locked ) this.dom.requestPointerLock?.()?.catch?.( () => {} );

	}

	down( code ) {

		return this.enabled && ( this.keys.has( code ) || this.virtualKeys.has( code ) );

	}

	// True once per physical key press or virtual touch-button transition.
	hit( code ) {

		return this.enabled && this.pressed.has( code );

	}

	// Mobile controls emit the same intents as keyboard input, so gameplay code has
	// one source of truth. A transition to down also counts as a one-frame press.
	setVirtual( code, down ) {

		if ( down ) {

			if ( ! this.virtualKeys.has( code ) ) this.pressed.add( code );
			this.virtualKeys.add( code );

		} else {

			this.virtualKeys.delete( code );

		}

	}

	tap( code ) {

		this.pressed.add( code );

	}

	addLook( x, y ) {

		if ( ! this.enabled ) return;
		this.look.x += Number.isFinite( x ) ? x : 0;
		this.look.y += Number.isFinite( y ) ? y : 0;

	}

	resetVirtual() {

		this.keys.clear();
		this.virtualKeys.clear();
		this.pressed.clear();
		this.mouseDown = false;
		this.rightDown = false;
		this.look.x = 0;
		this.look.y = 0;
		this.wheel = 0;

	}

	consumeLook() {

		const l = { x: this.look.x, y: this.look.y };
		this.look.x = 0;
		this.look.y = 0;
		return l;

	}

	consumeWheel() {

		const w = this.wheel;
		this.wheel = 0;
		return w;

	}

	endFrame() {

		this.pressed.clear();

	}

}
