import './core/TSLPatches.js';
import { App } from './App.js';
import { UI } from './ui/UI.js';
import { AppUI } from './ui/AppUI.js';
import { TouchControls } from './ui/TouchControls.js';
import { translate } from './ui/i18n.js';

document.documentElement.lang = 'zh-CN';
try { localStorage.setItem( 'tidewater.ui.language', 'zh-CN' ); } catch { /* storage may be unavailable */ }

const zh = ( text ) => translate( text, 'zh-CN' );

const ui = new UI();
const app = new App();
window.__ui = ui;

app.init( ( p, text ) => ui.setLoading( p, zh( text ) ) ).then( async () => {

	app.ui = new AppUI( app, ui );
	app.touch = new TouchControls( { input: app.input, root: ui.root } );
	ui.setLoading( 1, zh( 'Ready' ) );
	await ui.hideLoader();
	app.start();
	ui.showStartOverlay( () => {

		if ( app.touch?.enabled ) app.touch.enterImmersive();
		else app.input.requestLock();
		if ( app.audio ) app.audio.resume();

	} );

} ).catch( ( e ) => {

	console.error( e );
	ui.setLoading( null, '错误：' + e.message );

} );
