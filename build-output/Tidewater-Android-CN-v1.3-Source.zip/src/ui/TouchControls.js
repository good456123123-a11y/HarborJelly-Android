import { icon } from './icons.js';

const MOVE_KEYS = [ 'KeyW', 'KeyA', 'KeyS', 'KeyD', 'ShiftLeft' ];

const stop = ( e ) => {

	e.preventDefault();
	e.stopPropagation();

};

// Landscape phone controls. They only emit Input intents; movement, swimming and
// boat rules remain owned by Player, exactly like keyboard/mouse play.
export class TouchControls {

	static isTouchDevice() {

		const qs = new URLSearchParams( location.search );
		if ( qs.has( 'touch' ) ) return qs.get( 'touch' ) !== '0';
		return navigator.maxTouchPoints > 0 && matchMedia( '(pointer: coarse)' ).matches;

	}

	constructor( { input, root = document.body } ) {

		this.input = input;
		this.enabled = TouchControls.isTouchDevice();
		if ( ! this.enabled ) return;

		input.touch = true;
		document.documentElement.classList.add( 'tw-touch-device' );

		this.el = document.createElement( 'div' );
		this.el.className = 'tw-touch';
		this.el.setAttribute( 'aria-label', '手机触控操作' );
		this.el.innerHTML = `
			<div class="tw-touch-look tw-interactive" aria-label="拖动调整视角"></div>
			<div class="tw-stick tw-interactive" aria-label="移动摇杆">
				<div class="tw-stick-ring"></div>
				<div class="tw-stick-knob">${ icon( 'move' ) }</div>
				<div class="tw-stick-label">移动</div>
			</div>
			<div class="tw-touch-actions tw-interactive">
				<button class="tw-touch-btn tw-touch-flash" type="button" data-code="KeyL" aria-label="手电筒">${ icon( 'bolt' ) }<span>照明</span></button>
				<button class="tw-touch-btn tw-touch-camera" type="button" data-code="KeyV" aria-label="切换视角">${ icon( 'camera' ) }<span>视角</span></button>
				<button class="tw-touch-btn tw-touch-dive" type="button" data-hold="KeyC" aria-label="下潜">${ icon( 'dive' ) }<span>下潜</span></button>
				<button class="tw-touch-btn tw-touch-jump is-primary" type="button" data-hold="Space" aria-label="跳跃或上浮">${ icon( 'swim' ) }<span>跳跃</span></button>
				<button class="tw-touch-btn tw-touch-action is-primary" type="button" data-code="KeyE" aria-label="互动">${ icon( 'anchor' ) }<span>互动</span></button>
			</div>
			<div class="tw-rotate-hint"><div>${ icon( 'monitor' ) }<strong>请把手机横过来</strong><span>横屏才能正常操作</span></div></div>`;
		root.append( this.el );

		this.stick = this.el.querySelector( '.tw-stick' );
		this.knob = this.el.querySelector( '.tw-stick-knob' );
		this.look = this.el.querySelector( '.tw-touch-look' );
		this.action = this.el.querySelector( '.tw-touch-action span' );
		this.jump = this.el.querySelector( '.tw-touch-jump span' );
		this._bindStick();
		this._bindLook();
		this._bindButtons();

		window.addEventListener( 'blur', () => this.reset() );
		document.addEventListener( 'visibilitychange', () => {

			if ( document.hidden ) this.reset();

		} );

	}

	_bindStick() {

		let id = null;
		const move = ( e ) => {

			if ( e.pointerId !== id ) return;
			stop( e );
			const r = this.stick.getBoundingClientRect();
			const radius = r.width * 0.34;
			let x = e.clientX - ( r.left + r.width / 2 );
			let y = e.clientY - ( r.top + r.height / 2 );
			const raw = Math.hypot( x, y );
			if ( raw > radius ) {

				x *= radius / raw;
				y *= radius / raw;

			}
			this.knob.style.transform = `translate(${ x.toFixed( 1 ) }px, ${ y.toFixed( 1 ) }px)`;
			const nx = x / radius, ny = y / radius;
			this.input.setVirtual( 'KeyA', nx < - 0.22 );
			this.input.setVirtual( 'KeyD', nx > 0.22 );
			this.input.setVirtual( 'KeyW', ny < - 0.22 );
			this.input.setVirtual( 'KeyS', ny > 0.22 );
			this.input.setVirtual( 'ShiftLeft', Math.hypot( nx, ny ) > 0.82 );

		};
		const end = ( e ) => {

			if ( e.pointerId !== id ) return;
			stop( e );
			id = null;
			this._resetStick();

		};
		this.stick.addEventListener( 'pointerdown', ( e ) => {

			if ( id !== null ) return;
			stop( e );
			id = e.pointerId;
			this.stick.setPointerCapture?.( id );
			move( e );

		} );
		this.stick.addEventListener( 'pointermove', move );
		for ( const type of [ 'pointerup', 'pointercancel', 'lostpointercapture' ] ) this.stick.addEventListener( type, end );

	}

	_bindLook() {

		let id = null, x = 0, y = 0;
		const end = ( e ) => {

			if ( e.pointerId !== id ) return;
			stop( e );
			id = null;

		};
		this.look.addEventListener( 'pointerdown', ( e ) => {

			if ( id !== null ) return;
			stop( e );
			id = e.pointerId;
			x = e.clientX;
			y = e.clientY;
			this.look.setPointerCapture?.( id );

		} );
		this.look.addEventListener( 'pointermove', ( e ) => {

			if ( e.pointerId !== id ) return;
			stop( e );
			const dx = e.clientX - x, dy = e.clientY - y;
			x = e.clientX;
			y = e.clientY;
			this.input.addLook( dx * 1.25, dy * 1.25 );

		} );
		for ( const type of [ 'pointerup', 'pointercancel', 'lostpointercapture' ] ) this.look.addEventListener( type, end );

	}

	_bindButtons() {

		for ( const button of this.el.querySelectorAll( '.tw-touch-btn' ) ) {

			const hold = button.dataset.hold;
			const code = button.dataset.code;
			if ( code ) button.addEventListener( 'pointerdown', ( e ) => {

				stop( e );
				this.input.tap( code );
				button.classList.add( 'is-down' );
				setTimeout( () => button.classList.remove( 'is-down' ), 130 );

			} );
			if ( hold ) {

				const end = ( e ) => {

					stop( e );
					this.input.setVirtual( hold, false );
					button.classList.remove( 'is-down' );

				};
				button.addEventListener( 'pointerdown', ( e ) => {

					stop( e );
					button.setPointerCapture?.( e.pointerId );
					this.input.setVirtual( hold, true );
					button.classList.add( 'is-down' );

				} );
				for ( const type of [ 'pointerup', 'pointercancel', 'lostpointercapture' ] ) button.addEventListener( type, end );

			}

		}

	}

	_resetStick() {

		for ( const code of MOVE_KEYS ) this.input.setVirtual( code, false );
		if ( this.knob ) this.knob.style.transform = '';

	}

	reset() {

		if ( ! this.enabled ) return;
		this._resetStick();
		this.input.setVirtual( 'Space', false );
		this.input.setVirtual( 'KeyC', false );
		for ( const b of this.el.querySelectorAll( '.is-down' ) ) b.classList.remove( 'is-down' );

	}

	update( player ) {

		if ( ! this.enabled || ! player ) return;
		const mode = player.mode;
		this.el.dataset.mode = mode;
		this.jump.textContent = mode === 'swim' ? '上浮' : '跳跃';
		let action = '互动';
		if ( mode === 'boat' ) action = '下船';
		else if ( player.prompt?.text === 'Board boat' ) action = '上船';
		else if ( player.prompt?.text === 'Climb ladder' ) action = '攀爬';
		this.action.textContent = action;

	}

	async enterImmersive() {

		if ( ! this.enabled ) return;
		try {

			if ( ! document.fullscreenElement ) await document.documentElement.requestFullscreen?.( { navigationUI: 'hide' } );

		} catch { /* Fullscreen is optional in browsers and WebViews. */ }
		try {

			await screen.orientation?.lock?.( 'landscape' );

		} catch { /* Android manifest still locks the packaged app. */ }

	}

}
