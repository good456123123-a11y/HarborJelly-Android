import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three/webgpu';
import { BoatModel } from '../src/world/BoatModel.js';
import { BoatController } from '../src/player/BoatController.js';

const model = new BoatModel();
const up = new THREE.Vector3();
const point = new THREE.Vector3();

function simulate( { floor = () => -20, duration = 60, fps = 33, position = [0, 0, -30], speed = 0, heading = 0, tilt = 0, throttle = 0, steer = 0, waves = false } = {} ) {
 const q = { allocate: () => 1, latency: 0.06, cpuValid: false, version: 0, resultTime: 0, cpu: new Float32Array(256), resultInputs: new Float32Array(256) };
 const b = new BoatController( { model, query: q, terrain: { heightAt: floor }, colliders: null } );
 b.position.fromArray(position);
 b.quaternion.setFromEuler(new THREE.Euler(0, heading, tilt, 'YXZ'));
 b.velocity.set(0,0,speed).applyQuaternion(b.quaternion);
 b.moored = false;
 b.driven = throttle !== 0;
 let peakTilt = 0, peakRate = 0, peakHeight = -Infinity;
 for(let i = 0; i < duration * fps; i++) {
  const time = i / fps;
  // Exercise actual readQueries/update/interpolation at mobile frame rates.
  q.version++; q.resultTime = time; q.cpuValid = true;
  for(let j = 0; j < b.samples.length; j++) {
   b.toWorld(b.samples[j].p, point);
   const k = (b.slot + j) * 4;
   const phase = time * 1.6 + point.x * 0.08 + point.z * 0.11;
   const h = waves ? 0.45 * Math.sin(phase) : 0;
   const gx = waves ? 0.036 * Math.cos(phase) : 0;
   const gz = waves ? 0.0495 * Math.cos(phase) : 0;
   const ny = 1/Math.sqrt(1+gx*gx+gz*gz);
   q.cpu[k] = h; q.cpu[k+1] = -gx*ny; q.cpu[k+2] = -gz*ny;
   q.resultInputs[k] = point.x; q.resultInputs[k+1] = point.z;
  }
  b.setInput(throttle, steer, 1/fps);
  b.update(1/fps);
  assert.ok(b.isFinite());
  up.set(0,1,0).applyQuaternion(b.quaternion);
  peakTilt = Math.max(peakTilt, Math.acos(THREE.MathUtils.clamp(up.y,-1,1))*180/Math.PI);
  peakRate = Math.max(peakRate,b.angular.length());
  peakHeight = Math.max(peakHeight,b.position.y);
 }
 return { b, peakTilt, peakRate, peakHeight };
}

test('sloped shallow-water grounding stays upright (v1.2 capsized here)', () => {
 const r = simulate({floor:(x,z)=>0.1*x+0.06*z, position:[0,0,0]});
 assert.ok(r.peakTilt < 30, JSON.stringify({tilt:r.peakTilt}));
 assert.ok(r.peakRate < 1.5);
});

test('full throttle against sloped shore stays upright at 15/33/60 fps', () => {
 for(const fps of [15,33,60]) {
  const r = simulate({floor:(x,z)=>0.1*x+0.12*z, speed:7, throttle:1, steer:0.7, fps});
  assert.ok(r.peakTilt <= 35.01, `fps=${fps}, tilt=${r.peakTilt}`);
 }
});

test('striking a submerged sandbar at speed cannot capsize the hull', () => {
 const r = simulate({floor:(x,z)=>-3+3.2*Math.exp(-z*z/16),speed:10,throttle:1,duration:40});
 assert.ok(r.peakTilt <= 35.01);
 assert.ok(r.peakHeight < 4);
});

test('open water keeps natural wave motion and steering', () => {
 const r = simulate({waves:true,throttle:0.7,steer:0.3,duration:90});
 assert.ok(r.peakTilt > 1, 'boat must still rock with waves');
 assert.ok(r.peakTilt < 20);
 assert.ok(r.b.position.distanceTo(new THREE.Vector3(0,0,-30)) > 20, 'boat must still move');
 assert.ok(Math.abs(r.b.getYaw()) > 0.2, 'boat must still steer');
});

test('already overturned state rights itself while keeping location and heading', () => {
 const r = simulate({position:[0,0,-30],heading:1.2,tilt:Math.PI*0.8,duration:25});
 assert.ok(r.peakTilt <= 35.01);
 up.set(0,1,0).applyQuaternion(r.b.quaternion);
 assert.ok(up.y > 0.99);
 assert.ok(Math.abs(r.b.getYaw()-1.2) < 0.05);
 assert.ok(r.b.position.distanceTo(new THREE.Vector3(0,0,-30)) < 5);
});
