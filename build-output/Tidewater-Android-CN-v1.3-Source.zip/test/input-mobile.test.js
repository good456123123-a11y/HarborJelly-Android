import assert from 'node:assert/strict';
import test from 'node:test';

const windowTarget = new EventTarget();
const documentTarget = new EventTarget();
Object.assign( documentTarget, { hidden: false, pointerLockElement: null } );
globalThis.window = windowTarget;
globalThis.document = documentTarget;

const { Input } = await import( '../src/core/Input.js' );

const makeInput = () => {

	const surface = new EventTarget();
	surface.requestPointerLock = () => Promise.resolve();
	return new Input( surface );

};

test( 'virtual movement matches keyboard down state', () => {

	const input = makeInput();
	input.setVirtual( 'KeyW', true );
	assert.equal( input.down( 'KeyW' ), true );
	assert.equal( input.hit( 'KeyW' ), true );
	input.endFrame();
	assert.equal( input.down( 'KeyW' ), true );
	assert.equal( input.hit( 'KeyW' ), false );
	input.setVirtual( 'KeyW', false );
	assert.equal( input.down( 'KeyW' ), false );

} );

test( 'touch taps and look deltas are consumed exactly once', () => {

	const input = makeInput();
	input.tap( 'KeyE' );
	assert.equal( input.hit( 'KeyE' ), true );
	input.addLook( 12.5, -4 );
	assert.deepEqual( input.consumeLook(), { x: 12.5, y: -4 } );
	assert.deepEqual( input.consumeLook(), { x: 0, y: 0 } );
	input.endFrame();
	assert.equal( input.hit( 'KeyE' ), false );

} );

test( 'reset clears held touch controls and pending movement', () => {

	const input = makeInput();
	input.setVirtual( 'Space', true );
	input.addLook( 5, 7 );
	input.resetVirtual();
	assert.equal( input.down( 'Space' ), false );
	assert.equal( input.hit( 'Space' ), false );
	assert.deepEqual( input.consumeLook(), { x: 0, y: 0 } );

} );
